﻿Imports System.Data.SqlClient

Public Class DataAccessLayer
    Dim vSqlConnection As New SqlClient.SqlConnection("Data Source=vdevserv;Initial Catalog=pegor;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False")

    Public Function GetAllInterns() As Interns
        Try
            Dim vlDataSet As New Interns
            Dim vlSelectCommand As New SqlCommand
            Dim vlAdapter As New SqlDataAdapter(vlSelectCommand)

            vlSelectCommand.CommandType = CommandType.StoredProcedure
            vlSelectCommand.CommandText = "stp_GetAllInterns"
            vlSelectCommand.Connection = vSqlConnection

            Try
                vSqlConnection.Open()
            Catch ex As Exception
                Throw New ArgumentException("Failed to connect to database:" & vbNewLine & ex.Message)
            End Try

            Try
                vlAdapter.Fill(vlDataSet, "Intern")
            Catch ex As Exception
                Throw New ArgumentException("Failed to fill dataset:" & vbNewLine & ex.Message)
            End Try

            Return vlDataSet
        Catch ex As Exception
            Throw New ArgumentException("Failed to execute function:" & vbNewLine & ex.Message)
        Finally
            vSqlConnection.Close()
            vSqlConnection.Dispose()
        End Try
    End Function

    Public Function InsertIntern(ByVal pDataSet As Interns) As Boolean
        Try
            Dim vlDataRow As DataRow = pDataSet.Intern.Rows.Item(0)
            Dim vlInsertCommand As New SqlCommand
            Dim vlReturnValue As Integer

            vlInsertCommand.CommandType = CommandType.StoredProcedure
            vlInsertCommand.CommandText = "stp_AddIntern"

            vlInsertCommand.Parameters.Add("@FName", SqlDbType.NVarChar, 50).Value = vlDataRow.Item("FName")
            vlInsertCommand.Parameters.Add("@LName", SqlDbType.NVarChar, 50).Value = vlDataRow.Item("LName")
            vlInsertCommand.Parameters.Add("@Phone", SqlDbType.Int).Value = vlDataRow.Item("Phone")
            vlInsertCommand.Parameters.Add("@Email", SqlDbType.NVarChar, 50).Value = vlDataRow.Item("Email")
            vlInsertCommand.Parameters.Add("@Country", SqlDbType.NVarChar, 50).Value = vlDataRow.Item("Country")
            vlInsertCommand.Parameters.Add("@City", SqlDbType.NVarChar, 50).Value = vlDataRow.Item("City")
            vlInsertCommand.Parameters.Add("@Area", SqlDbType.NVarChar, 50).Value = vlDataRow.Item("Area")
            vlInsertCommand.Parameters.Add("@Street", SqlDbType.NVarChar, 50).Value = vlDataRow.Item("Street")
            vlInsertCommand.Parameters.Add("@Building", SqlDbType.NVarChar, 50).Value = vlDataRow.Item("Building")
            vlInsertCommand.Parameters.Add("@Floor", SqlDbType.Int).Value = vlDataRow.Item("Floor")
            vlInsertCommand.Connection = vSqlConnection

            Try
                vSqlConnection.Open()
            Catch ex As Exception
                Throw New ArgumentException("Failed to connect to database:" & vbNewLine & ex.Message)
            End Try

            Try
                vlReturnValue = vlInsertCommand.ExecuteNonQuery()
            Catch ex As Exception
                Throw New ArgumentException("Failed to execute SQL command:" & vbNewLine & ex.Message)
            End Try

            If vlReturnValue = 0 Then
                Throw New ArgumentException("0 rows modified")
            Else
                Return True
            End If

        Catch ex As Exception
            Throw New ArgumentException("Failed to execute function:" & vbNewLine & ex.Message)
        Finally
            vSqlConnection.Close()
        End Try
    End Function

End Class
