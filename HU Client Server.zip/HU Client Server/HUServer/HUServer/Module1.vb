﻿Imports System.Net.Sockets
Imports System.Text
Imports System.Net
Imports System.Threading
Imports System.IO

Module Module1
    Private nSockets As ArrayList

    Sub Main()
        Console.WriteLine("Server Starting...")
        nSockets = New ArrayList()

        'create and start a new thread which will listen for incoming connections
        Dim thdListener As New Thread(New ThreadStart(AddressOf listenerThread))
        thdListener.Start()
    End Sub


    Public Sub listenerThread()
        Dim tcpListener As New TcpListener(IPAddress.Parse("127.0.0.1"), 8080)
        Dim handlerSocket As Socket
        Dim thdstHandler As ThreadStart
        Dim thdHandler As Thread
        Dim lock As New Object
        tcpListener.Start()

        'listen for incoming connection requests, if one is made add it to the SocketArrayList. this allows the server to handle multiple clients at the same time
        Do
            handlerSocket = tcpListener.AcceptSocket()
            If handlerSocket.Connected Then
                Console.WriteLine(handlerSocket.RemoteEndPoint.ToString() + " connected.")

                SyncLock lock
                    nSockets.Add(handlerSocket)
                End SyncLock

                'create and start a new handler thread which will handle incoming requests from a specific client
                thdstHandler = New ThreadStart(AddressOf handlerThread)
                thdHandler = New Thread(thdstHandler)
                thdHandler.Start()
            End If
        Loop
    End Sub

    Public Sub handlerThread()
        Dim handlerSocket As Socket
        handlerSocket = nSockets(nSockets.Count - 1)
        Dim networkStream As NetworkStream = New NetworkStream(handlerSocket)
        Dim BufferSize As Short = handlerSocket.ReceiveBufferSize
        Dim DataByte(BufferSize) As Byte
        Dim clientdatatemp As String = ""

        'receive request from client
        Do
            networkStream.Read(DataByte, 0, BufferSize)
            clientdatatemp += Encoding.ASCII.GetString(DataByte)
        Loop While networkStream.DataAvailable
        Dim clientdata As String = clientdatatemp.Substring(0, clientdatatemp.IndexOf(Chr(3)))

        'determine what is the incoming request and respong accordingly
        Select Case clientdata(0)
            Case "1"
                'Call the Get function and convert the filled dataset into a string and send it back to the client
                Dim DAL As New DataAccessLayer
                Dim DataSetAsString As String = DAL.GetAllInterns.GetXml
                Dim SendData() As Byte = Encoding.ASCII.GetBytes(DataSetAsString & Chr(3))
                networkStream.Write(SendData, 0, SendData.Length)
            Case "2"
                'Convert received string into dataset in order to be able to insert a new row
                Dim sr As New StringReader(clientdata.Substring(2))
                Dim DataSet As New Interns
                DataSet.ReadXml(sr, XmlReadMode.ReadSchema)

                'Call the insert function, to insert a new intern
                Dim DAL As New DataAccessLayer
                DAL.InsertIntern(DataSet)

                'Call the get function to get updated list of all interns, convert it into a string and send to the client
                Dim DataSetAsString As String = DAL.GetAllInterns.GetXml
                Dim SendData() As Byte = Encoding.ASCII.GetBytes(DataSetAsString & Chr(3))
                networkStream.Write(SendData, 0, SendData.Length)
        End Select
       
        handlerSocket = Nothing
    End Sub
End Module
