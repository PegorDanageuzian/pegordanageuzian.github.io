﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Client
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Add = New System.Windows.Forms.Button()
        Me.Interns = New HUClient.Interns()
        Me.grdInterns = New System.Windows.Forms.DataGridView()
        CType(Me.Interns, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdInterns, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Add
        '
        Me.Add.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Add.Location = New System.Drawing.Point(1060, 478)
        Me.Add.Name = "Add"
        Me.Add.Size = New System.Drawing.Size(75, 23)
        Me.Add.TabIndex = 0
        Me.Add.Text = "Add"
        Me.Add.UseVisualStyleBackColor = True
        '
        'Interns
        '
        Me.Interns.DataSetName = "Interns"
        Me.Interns.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'grdInterns
        '
        Me.grdInterns.AllowUserToAddRows = False
        Me.grdInterns.AllowUserToDeleteRows = False
        Me.grdInterns.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grdInterns.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdInterns.Location = New System.Drawing.Point(12, 12)
        Me.grdInterns.Name = "grdInterns"
        Me.grdInterns.ReadOnly = True
        Me.grdInterns.Size = New System.Drawing.Size(1123, 460)
        Me.grdInterns.TabIndex = 2
        '
        'Client
        '
        Me.AcceptButton = Me.Add
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1147, 513)
        Me.Controls.Add(Me.grdInterns)
        Me.Controls.Add(Me.Add)
        Me.Name = "Client"
        Me.Text = "Client"
        CType(Me.Interns, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdInterns, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Add As System.Windows.Forms.Button
    Friend WithEvents Interns As HUClient.Interns
    Friend WithEvents grdInterns As System.Windows.Forms.DataGridView

End Class
