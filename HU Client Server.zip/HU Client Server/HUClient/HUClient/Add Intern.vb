﻿Public Class Add_Intern

    Private INTERN(9) As Object

    Public Property _intern
        Get
            Return INTERN
        End Get
        Set(value)
            INTERN = value
        End Set
    End Property

    Private Sub Add_Intern_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


    Private Sub Ok_Click(sender As Object, e As EventArgs) Handles Ok.Click
        Try
            If TextBox1.Text Is Nothing Or TextBox2.Text Is Nothing Then
                Throw New ArgumentException()
            Else
                INTERN(0) = TextBox1.Text
                INTERN(1) = TextBox2.Text
                INTERN(2) = CInt(TextBox3.Text)
                INTERN(3) = TextBox4.Text
                INTERN(4) = TextBox5.Text
                INTERN(5) = TextBox6.Text
                INTERN(6) = TextBox7.Text
                INTERN(7) = TextBox8.Text
                INTERN(8) = TextBox9.Text
                INTERN(9) = CInt(TextBox10.Text)
                Me.DialogResult = Windows.Forms.DialogResult.OK
            End If
        Catch ex As Exception
            MessageBox.Show("Please Input Valid Data," & vbNewLine & "FName and LName cannot be empty" & vbNewLine & "Phone and Floor must be positive numbers.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1)
            Me.DialogResult = Windows.Forms.DialogResult.None
        End Try

    End Sub

   
End Class