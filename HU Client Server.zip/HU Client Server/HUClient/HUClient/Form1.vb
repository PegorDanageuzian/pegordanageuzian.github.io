﻿Imports System.Net.Sockets
Imports System.Net
Imports System.Text
Imports System.Threading
Imports System.IO

Public Class Client

    Private Sub Client_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Open a connection with the server and request all interns
        Dim clientSocket As New TcpClient("127.0.0.1", 8080)
        Dim networkStream As NetworkStream
        networkStream = clientSocket.GetStream()
        Dim SendData() As Byte = Encoding.ASCII.GetBytes("1" & Chr(3))
        networkStream.Write(SendData, 0, SendData.Length)

        'Recevie the reply from the server, that contains all the interns
        Dim BufferSize As Short = clientSocket.ReceiveBufferSize
        Dim DataByte(BufferSize) As Byte
        Dim clientdatatemp As String = ""
        Do
            networkStream.Read(DataByte, 0, BufferSize)
            clientdatatemp += Encoding.ASCII.GetString(DataByte)
        Loop While networkStream.DataAvailable

        'store all the interns as a string
        Dim clientdata As String = clientdatatemp.Substring(0, clientdatatemp.IndexOf(Chr(3)))

        'fill client copy of the dataset with all the interns
        Dim DataSet As New Interns
        Dim sr As New StringReader(clientdata)
        DataSet.ReadXml(sr, XmlReadMode.ReadSchema)

        'bind the data grid to the client's dataset
        grdInterns.DataSource = DataSet.Intern
        grdInterns.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    End Sub

    Private Sub Add_Click(sender As Object, e As EventArgs) Handles Add.Click

        'create form for new intern and show as dialog
        Dim NewInternForm As New Add_Intern
        Dim vlResult As DialogResult = NewInternForm.ShowDialog(Me)
        If vlResult = Windows.Forms.DialogResult.OK Then

            'Store new intern in a new dataset
            Dim DataSet As New Interns
            DataSet.Intern.AddInternRow(NewInternForm._intern(0), NewInternForm._intern(1), NewInternForm._intern(2), NewInternForm._intern(3), NewInternForm._intern(4), _
                                        NewInternForm._intern(5), NewInternForm._intern(6), NewInternForm._intern(7), NewInternForm._intern(8), NewInternForm._intern(9))

            'convert the dataset into a string and send it along with and insert command to the server
            Dim DataSetAsString As String = DataSet.GetXml
            Dim clientSocket As New TcpClient("127.0.0.1", 8080)
            Dim networkStream As NetworkStream
            networkStream = clientSocket.GetStream()
            Dim SendData() As Byte = Encoding.ASCII.GetBytes("2" & vbNewLine & DataSetAsString & Chr(3))
            networkStream.Write(SendData, 0, SendData.Length)

            'receive server reply
            Dim BufferSize As Short = clientSocket.ReceiveBufferSize
            Dim DataByte(BufferSize) As Byte
            Dim clientdatatemp As String = ""
            Do
                networkStream.Read(DataByte, 0, BufferSize)
                clientdatatemp += Encoding.ASCII.GetString(DataByte)
            Loop While networkStream.DataAvailable

            Dim clientdata As String = clientdatatemp.Substring(0, clientdatatemp.IndexOf(Chr(3)))

            DataSet = New Interns
            Dim sr As New StringReader(clientdata)
            DataSet.ReadXml(sr, XmlReadMode.ReadSchema)

            grdInterns.DataSource = DataSet.Intern
            grdInterns.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        End If

    End Sub
End Class
